This is where an output of .mca files will come.
Read here for more instructions: https://forums.pocketmine.net/threads/leveldb-maps-to-anvil.12018/
